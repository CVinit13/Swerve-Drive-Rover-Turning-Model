from pathlib import Path
import csv, json, math
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).parent
FIG = ROOT / 'figures'
RESULT = ROOT / 'results'
OUT = ROOT / 'Swerve_Rover_Research_Draft.docx'

# ---------- CSV source artifacts ----------
literature = [
    {"ref":"[1]","citation":"Lee & Li (2015), Kinematics, dynamics and control design of 4WIS4WID mobile robots","doi":"10.1049/joe.2014.0241","objective_model":"Kinematic and Lagrangian dynamic model for four independently steered and driven wheels; 11-state formulation and trajectory controller.","validation":"Computer simulations and controller comparisons.","limitations_relevance":"Directly establishes that 4WIS/4WID kinematics and dynamics are already studied. No specific two-stage signed planetary transmission is the focus of the abstract/methods inspected."},
    {"ref":"[2]","citation":"Zheng & Yang (2019), A Trajectory Tracking Control Strategy of 4WIS/4WID Electric Vehicle with Adaptation of Driving Conditions","doi":"10.3390/app9010168","objective_model":"Three-degree-of-freedom vehicle model, tire-force distribution and hierarchical trajectory tracking under varied conditions.","validation":"Numerical simulation.","limitations_relevance":"Relevant on tire-force coupling and per-wheel actuator allocation; it means force distribution is not a novel contribution by itself."},
    {"ref":"[3]","citation":"Jaskot, Posiadała & Śpiewak (2017), Dynamics modelling of the four-wheeled mobile platform","doi":"10.1016/j.mechrescom.2017.05.007","objective_model":"Four-wheel platform dynamics for progressive/rotational motion with wheel slip and resistive forces.","validation":"Numerical solution using fourth-order Runge-Kutta and prototype-oriented geometry; source description reports simulation results.","limitations_relevance":"Shows four-wheel dynamics and slip are established topics; exact mechanical configuration differs."},
    {"ref":"[4]","citation":"Hong, Velinsky & Feng (1999), Verification of a Wheeled Mobile Robot Dynamic Model and Control Ramifications","doi":"10.1115/1.2802442","objective_model":"Dynamic model with tire-ground interaction for a heavy differentially steered robot.","validation":"Experimental data in loaded and unloaded conditions.","limitations_relevance":"Not a swerve-drive platform, but a strong precedent for needing physical validation beyond dimensional checks or simulation."},
    {"ref":"[5]","citation":"Seo, Moon & Kang (2026), Unified motion control of 4WIS-4WID WMR with unlimited steering and load transfer consideration","doi":"10.1016/j.robot.2026.105341","objective_model":"Unified 4WIS/4WID controller accounting for tire slip, load transfer, Magic Formula friction constraints, and steering/drive allocation.","validation":"Check publisher paper for its exact simulation/experimental scope before citing detailed performance claims; abstract inspected describes the framework.","limitations_relevance":"Very close contemporary prior art on friction-constrained 4WIS/4WID modelling. Generic claims about coupling steering, tire forces and load transfer are not novel."},
    {"ref":"[6]","citation":"Liu & Hashimoto (2026), Friction-Aware Force-Realizable Safety Control for Four-Wheel Independently Steered and Driven Mobile Robots","doi":"10.1002/rnc.70772","objective_model":"Friction-aware safety control with torque constraints, conservative friction lower-bound estimation and force-realizable allocation.","validation":"Numerical simulation study; article first published online 3 October 2026.","limitations_relevance":"Current work on force/torque feasibility. Not a planetary transmission design paper but narrows the viable novelty of an integrated friction-feasibility claim."},
    {"ref":"[7]","citation":"del Castillo (2002), The analytical expression of the efficiency of planetary gear trains","doi":"10.1016/S0094-114X(01)00077-5","objective_model":"Analytical procedures to derive efficiency expressions for planetary gear trains from speed/torque relations and power flow.","validation":"Analytical derivation; inspect the full article before relying on a particular loss model.","limitations_relevance":"Supports deriving the signed kinematics separately from efficiency. The constant 0.92 per stage in the design PDF is an assumption, not a verified operating-point efficiency."},
    {"ref":"[8]","citation":"Talbot, Kahraman & Singh (2012), An Experimental Investigation of the Efficiency of Planetary Gear Sets","doi":"10.1115/1.4005599","objective_model":"Measured spin and mechanical losses in planetary gear sets across load, speed, planet count, roughness and oil-temperature conditions.","validation":"Purpose-built test apparatus and measured power loss.","limitations_relevance":"Indicates transmission efficiency depends on operating condition and hardware details; measure or calibrate it if precise power predictions are claimed."},
    {"ref":"[9]","citation":"Nutakor et al. (2017), Planetary gear sets power loss modeling: Application to wind turbines","doi":"10.1016/j.triboint.2016.09.029","objective_model":"Power-loss model including non-uniform planet load sharing, gear-mesh losses, bearing losses and lubricant drag.","validation":"Compared predictions with previously published experimental measurements.","limitations_relevance":"Provides a higher-fidelity alternative to a single fixed stage efficiency; application differs in scale and duty."},
    {"ref":"[10]","citation":"Song & Byun (2004), Design and Control of a Four-Wheeled Omnidirectional Mobile Robot with Steerable Omnidirectional Wheels","doi":"10.1002/rob.20009","objective_model":"Kinematic/dynamic analysis of a steerable omnidirectional-wheel platform.","validation":"Prototype and tests reported by the publisher abstract.","limitations_relevance":"Related mobility literature, but steerable omniwheels are not conventional swerve modules; use only as adjacent context."},
]
with (ROOT/'literature_matrix.csv').open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=list(literature[0].keys())); w.writeheader(); w.writerows(literature)

audits = [
    {"item":"Drive stage 1 ratio","source_value":"4:1 magnitude; sun input, ring fixed, carrier output","recalculation":"Willis: (ωs−ωc)/(0−ωc)=−69/23 gives ωc=+ωs/4","status":"Confirmed; positive signed speed ratio","implication":"Stage 1 carrier rotates in same direction as sun."},
    {"item":"Drive stage 2 ratio","source_value":"3:1 magnitude; sun input, carrier fixed, ring output","recalculation":"Willis with ωc=0 gives ωr/ωs=−Zs/Zr=−1/3","status":"Magnitude confirmed; signed direction omitted in source summary","implication":"Stage 2 ring reverses direction relative to sun; combined ωwheel/ωmotor=−1/12 if stage 1 carrier drives stage 2 sun."},
    {"item":"Steering gearbox ratio","source_value":"6:1; sun input, ring fixed, carrier output","recalculation":"ωc/ωs=Zs/(Zs+Zr)=18/108=+1/6","status":"Confirmed","implication":"Carrier and sun rotate in the same direction."},
    {"item":"Total drive efficiency","source_value":"Text renders as 0.922 = 0.8464","recalculation":"ηtotal=0.92×0.92=0.8464","status":"Notation / typographical issue","implication":"The motor torque calculation uses 0.8464, which is consistent with the stage assumption."},
    {"item":"Wheel and motor speed","source_value":"120.6 rpm wheel; 1447.2 rpm motor; 151.5 rad/s","recalculation":"ωw=v/r=1.2/0.095=12.632 rad/s =120.62 rpm; |ωm|=12|ωw|=151.58 rad/s =1447.47 rpm","status":"Correct magnitude; motor-to-wheel sign is negative","implication":"Controller must apply the direction mapping; use a signed ratio in software."},
    {"item":"Per-module force demand","source_value":"Froll=5.89 N; Fgrade=25.65 N; Faccel=24 N; total=55.54 N","recalculation":"For a 30 kg payload share, using N=mg cos5°, Froll=5.864 N, Fgrade=25.650 N, Faccel=24 N, total=55.514 N","status":"Arithmetic acceptable; cosine correction is small","implication":"55.5 N is per module under equal payload allocation, not whole-rover total. Four modules imply about 222.1 N for payload-only mass."},
    {"item":"Traction check","source_value":"μN=206.0 N >55.54 N","recalculation":"μmg cos5°=205.23 N per payload-only module; utilization 55.514/205.226=0.2705","status":"Passes simple longitudinal-only check under assumptions","implication":"Does not establish turning feasibility; longitudinal and lateral tire demands share friction capacity."},
    {"item":"Drive torque and power","source_value":"Twheel=5.276 Nm; Tmotor=0.520 Nm; Pmotor=78.8 W","recalculation":"Twheel=55.514×0.095=5.274 Nm; Tmotor=5.274/(12×0.8464)=0.5192 Nm; P=78.71 W at 151.58 rad/s","status":"Confirmed to rounding","implication":"Per module; excludes chassis mass and relies on fixed efficiency."},
    {"item":"Design torque / factor of safety","source_value":"×2 design values: 10.552 Nm wheel, 1.040 Nm motor","recalculation":"Twice the operational payload-only result gives 10.548 Nm and 1.038 Nm with cosine-corrected force","status":"Consistent in principle","implication":"FoS-adjusted load is for strength/design checks, not physical dynamic mass."},
    {"item":"Steering scrub torque","source_value":"(2/3) μ N rc =2.06 Nm; design 4.12 Nm","recalculation":"2/3×0.7×294.3×0.015=2.06 Nm","status":"Arithmetic correct; physical model uncertain","implication":"Formula assumes a circular patch with uniform pressure, while the PDF also specifies a 30×15 mm rectangular patch. Validate the moment experimentally and include any mechanical scrub radius separately."},
    {"item":"Contact pressure","source_value":"450 mm² patch; 0.654 MPa operational; 1.308 MPa design","recalculation":"30×15=450 mm²; 294.3/4.5e−4=0.654 MPa","status":"Arithmetic correct","implication":"Nominal average pressure only; actual patch geometry/pressure distribution is not established."},
    {"item":"Bearing L10 life","source_value":"L10≈4.72×10^5 h","recalculation":"(C/P)^3×10^6/(60n), C=4900 N, P=591.2 N, n=120.6 rpm gives ≈7.87×10^4 h","status":"Arithmetic error in source calculation","implication":"Still above 10,000 h numerically, but only if equivalent load, speed, reliability and load path assumptions are correct."},
    {"item":"Gear tooth stress estimates","source_value":"Large bending and contact safety factors are reported","recalculation":"Simple Lewis/Hertz arithmetic can be reproduced, but several load factors and geometry/strength assumptions are not traceable to a cited rating standard or tested data","status":"Preliminary sanity check only","implication":"Do not use the quoted safety factors as a certified gear rating; complete a standard-based rating with quality, life, load-sharing, duty and material data."},
    {"item":"Planet-neighbour clearance check","source_value":"(Zs+Zp)sin(180/N)>Zp+2","recalculation":"The inequality is not accompanied by a derivation or direct addendum-circle clearance construction","status":"Needs geometric validation","implication":"Verify actual center distances and clearances in CAD with tolerances and tooth addenda; do not treat the line alone as proof of no interference."},
    {"item":"Mass / load basis","source_value":"120 kg payload; 30 kg/module; FoS 2 design load","recalculation":"Total physical mass must be m=120 kg + chassis, wheels, batteries, actuators and other hardware","status":"Incomplete for full vehicle dynamics","implication":"Do not silently use 120 kg as true operating mass. Use it only as a payload-only lower-bound example until weighed."},
]
with (ROOT/'calculation_audit.csv').open('w', newline='', encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=list(audits[0].keys())); w.writeheader(); w.writerows(audits)

# ---------- DOCX helpers ----------
def set_cell_shading(cell, fill='D9EAF7'):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill); tcPr.append(shd)

def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader'); tblHeader.set(qn('w:val'), 'true'); trPr.append(tblHeader)

def set_cell_text(cell, text, bold=False, size=8.2, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    for j,line in enumerate(str(text).split('\n')):
        if j:
            p.add_run().add_break()
        r = p.add_run(line)
        r.bold = bold; r.font.size = Pt(size); r.font.name = 'Arial'
        if color: r.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_table(doc, headers, rows, widths=None, font_size=8.0):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for i,h in enumerate(headers):
        set_cell_text(hdr.cells[i], h, bold=True, size=font_size, color=(255,255,255))
        set_cell_shading(hdr.cells[i], '1F4E79')
    for row in rows:
        cells = table.add_row().cells
        for i,v in enumerate(row):
            set_cell_text(cells[i], v, size=font_size)
            if len(table.rows) % 2 == 0:
                set_cell_shading(cells[i], 'F3F6F9')
    if widths:
        for row in table.rows:
            for i,w in enumerate(widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table

def add_para(doc, text='', style=None, bold_lead=None, italic=False, align=None, keep=False):
    p = doc.add_paragraph(style=style)
    if align is not None:
        p.alignment = align
    if keep:
        p.paragraph_format.keep_with_next = True
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead); r.bold=True
        p.add_run(text[len(bold_lead):])
    else:
        r=p.add_run(text); r.italic=italic
    return p

def add_eq(doc, text, number):
    p=doc.add_paragraph()
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before=Pt(2); p.paragraph_format.space_after=Pt(3)
    p.paragraph_format.keep_together=True
    r=p.add_run(f'{text}     ({number})')
    r.font.name='Cambria Math'; r.font.size=Pt(10)
    return p

def add_bullets(doc, items):
    for x in items:
        p=doc.add_paragraph(style='List Bullet')
        p.paragraph_format.space_after=Pt(2)
        p.add_run(x)

def add_numbered(doc, items):
    for x in items:
        p=doc.add_paragraph(style='List Number')
        p.paragraph_format.space_after=Pt(2)
        p.add_run(x)

def add_manual_numbered(doc, items):
    # Explicit labels avoid Word continuing numbering across distant list sections.
    for idx, x in enumerate(items, 1):
        p=doc.add_paragraph()
        p.paragraph_format.left_indent=Inches(0.25)
        p.paragraph_format.first_line_indent=Inches(-0.22)
        p.paragraph_format.space_after=Pt(3)
        p.add_run(f'{idx}.  {x}')

def add_figure(doc, path, caption, width=6.1):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path), width=Inches(width))
    c=doc.add_paragraph(); c.alignment=WD_ALIGN_PARAGRAPH.CENTER
    c.paragraph_format.space_after=Pt(7)
    r=c.add_run(caption); r.italic=True; r.font.size=Pt(8.5)

def add_h(doc, text, level=1):
    p=doc.add_heading(text, level=level)
    p.paragraph_format.keep_with_next=True
    return p

def set_page_field(paragraph):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=paragraph.add_run('Page ')
    fldChar1=OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'),'begin')
    instrText=OxmlElement('w:instrText'); instrText.set(qn('xml:space'),'preserve'); instrText.text=' PAGE '
    fldChar2=OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'),'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)
    for r in paragraph.runs: r.font.size=Pt(8); r.font.color.rgb=RGBColor(100,100,100)

# ---------- Manuscript ----------
doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(0.68); sec.bottom_margin=Inches(0.66)
sec.left_margin=Inches(0.78); sec.right_margin=Inches(0.78)
sec.header_distance=Inches(0.32); sec.footer_distance=Inches(0.32)
styles=doc.styles
styles['Normal'].font.name='Arial'; styles['Normal'].font.size=Pt(9.3)
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'),'Arial')
styles['Normal'].paragraph_format.space_after=Pt(5)
styles['Normal'].paragraph_format.line_spacing=1.06
for sn,sz in [('Heading 1',14),('Heading 2',11.5),('Heading 3',10)]:
    st=styles[sn]; st.font.name='Arial'; st.font.size=Pt(sz); st.font.bold=True
    st.font.color.rgb=RGBColor(31,78,121)
    st.paragraph_format.space_before=Pt(9); st.paragraph_format.space_after=Pt(4)
header=sec.header.paragraphs[0]
header.text='CONFIGURATION-SPECIFIC SWERVE ROVER MODEL | RESEARCH DRAFT'
header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
for r in header.runs:
    r.font.name='Arial'; r.font.size=Pt(7.5); r.font.color.rgb=RGBColor(100,100,100)
set_page_field(sec.footer.paragraphs[0])

p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before=Pt(22); p.paragraph_format.space_after=Pt(8)
r=p.add_run('Configuration-Specific Modelling and Feasibility Audit of a Four-Wheel Swerve-Drive Rover with Compound Planetary Transmissions')
r.bold=True; r.font.name='Arial'; r.font.size=Pt(19); r.font.color.rgb=RGBColor(31,78,121)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Research manuscript draft with reproducible reduced-order simulation'); r.italic=True; r.font.size=Pt(11)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Version 1.0 | 15 October 2026'); r.font.size=Pt(9); r.font.color.rgb=RGBColor(100,100,100)

p=doc.add_paragraph(); p.paragraph_format.space_before=Pt(10); p.paragraph_format.space_after=Pt(10)
r=p.add_run('IMPORTANT STATUS NOTE. '); r.bold=True; r.font.color.rgb=RGBColor(156,0,6)
p.add_run('This is a technically grounded research draft, not a submission-ready or experimentally validated paper. The attached calculation PDF does not provide total rover mass, wheel-module spacing, yaw inertia, selected motor torque-speed curves, or identified tire parameters. The executable examples use clearly labelled illustrative placeholders. No prototype measurements are claimed. Novelty remains provisional because closely related 4WIS/4WID models and friction-constrained controllers already exist.')

add_h(doc,'Abstract',1)
add_para(doc,'This work develops a traceable, configuration-specific modelling framework for a square four-wheel swerve-drive rover whose wheel-drive and steering axes are actuated through compound planetary transmissions. The starting design specifies a 120 kg payload, 190 mm wheels, a two-stage drive gearbox with 23/23/69-tooth sun/planet/ring geometry in both stages, and an 18/36/90-tooth steering stage. The signed Willis relation gives a +1/4 speed ratio for the first drive stage, a -1/3 ratio for the second stage, and an overall wheel-to-drive-motor speed ratio of -1/12; the steering carrier-to-sun ratio is +1/6. With a 30 kg payload share per module, a 0.8 m/s² acceleration target, a 5° grade and a rolling-resistance coefficient of 0.02, the recalculated longitudinal demand is approximately 55.5 N per module. This corresponds to about 5.27 N m at the wheel and 0.519 N m at the drive motor at 1.2 m/s when each stage is assumed to be 92% efficient. A friction-circle wheel-force model, wheel and steering actuator limits, and planar Newton-Euler equations are then combined into a reduced-order ordinary differential equation model. Analytical checks pass for the signed ratios, straight-line kinematics, ideal in-place wheel speed and power accounting. Controller-in-the-loop plots are generated only as software demonstrations under illustrative missing-parameter values, not as predictions for a built rover. The audit also identifies a bearing-life arithmetic error in the source sheet and several unresolved physical-model and gear-rating assumptions. The present contribution is therefore best regarded as a configuration-specific feasibility and reproducibility framework; a stronger novelty claim and journal submission require CAD-derived inertial properties, motor curves, measured tire/steering resistance, an expanded literature review and experimental validation.')
add_para(doc,'Keywords: four-wheel independent steering and drive; swerve-drive rover; planetary gearbox; Willis equation; friction circle; yaw dynamics; actuator feasibility; model verification')

add_h(doc,'Nomenclature',1)
nom=[
('a_i = (x_i,y_i)','Position of wheel module i relative to the centre of gravity [m]'),('C_x, C_y','Illustrative longitudinal/lateral creepage coefficients [N s/m]'),('F_ti, F_li','Gross longitudinal traction and lateral tire force in wheel coordinates [N]'),('F_ix, F_iy','Wheel contact-force components in body coordinates [N]'),('I_z','Rover yaw moment of inertia [kg m²]'),('J_w, J_δ','Wheel and steering-module equivalent inertias [kg m²]'),('L','Square wheel-module centre spacing [m]'),('m','Total physical rover mass, including payload and hardware [kg]'),('N_i','Wheel normal load [N]'),('r_w','Wheel radius [m]'),('u, v','Body-frame longitudinal and lateral CG velocities [m/s]'),('ω_z','Chassis yaw rate [rad/s]'),('δ_i','Steering angle of module i relative to chassis [rad]'),('η_d, η_s','Drive and steering transmission efficiencies [-]'),('μ, μ_r','Tire-ground traction coefficient and rolling-resistance coefficient [-]'),('τ_m, τ_w','Drive motor torque and wheel-shaft torque [N m]')]
add_table(doc,['Symbol','Definition / unit'],nom,[1.75,4.9],8.3)

add_h(doc,'1. Introduction and research question',1)
add_para(doc,'A four-wheel independently steered and driven (4WIS/4WID) platform can translate in arbitrary planar directions and rotate about its centre by coordinating four steering angles and four wheel-drive speeds. Yet the kinematic ability to request a manoeuvre does not guarantee that the motor torque, gearbox, tire-ground contact, and chassis inertia can realize it. Existing work has already developed kinematic and dynamic models for 4WIS/4WID robots, used tire-force distribution, and studied friction or load-transfer constraints [1-3,5,6]. The objective here is therefore not to claim novelty for general swerve kinematics or planar rigid-body dynamics.')
add_para(doc,'The focused research question is: for the specified two-stage planetary drive train and one-stage steering train, how should signed gear kinematics, actuator limits, friction-limited wheel forces and yaw dynamics be coupled to quantify the feasibility of a requested turning manoeuvre, and what missing measurements prevent the design from making a defensible performance prediction?')
add_para(doc,'The provisional contributions are: (i) an auditable derivation of the signed ratios for the unusual carrier-output / ring-output drive-stage pairing; (ii) a parameterized mapping from motor torque-speed envelopes to wheel force and yaw-acceleration feasibility; (iii) a low-speed, friction-constrained rover model with explicit separation between steering-joint torque and the external tire-ground moments acting on the rover; and (iv) a reproducible software package with analytical verification checks and a design-specific audit. Whether these contributions are sufficiently novel for a journal is not established. Broad 4WIS/4WID model integration and force-constrained control already have significant prior art, including very recent work [5,6].')

add_h(doc,'2. Targeted literature review and candidate gap',1)
add_para(doc,'A targeted search of publisher pages and DOI-indexed records was conducted for 4WIS/4WID kinematics and dynamics, tire-force feasibility, planetary gear efficiency and experimental model validation. This is not an exhaustive systematic review: a final journal submission should extend the search through Scopus/Web of Science/IEEE Xplore, use explicit search strings and screening rules, and inspect full methods/results for the closest papers.')
rows=[]
for item in literature:
    rows.append((item['ref'],item['citation'].split(',')[0],item['objective_model'],item['validation'],item['limitations_relevance']))
add_table(doc,['Ref. / work','Model or objective','Evidence inspected','Implication / limitation'],
         [(r[0]+' '+r[1],r[2],r[3],r[4]) for r in rows], [1.55,2.05,1.25,2.25],7.0)
add_para(doc,'The key finding from this scan is negative but useful: kinematic modelling, planar dynamics, tire-force allocation and friction limits are not new in isolation. Lee and Li present a 4WIS/4WID kinematic-dynamic framework; Zheng and Yang develop a three-degree-of-freedom vehicle model and force-distribution strategy; Jaskot and colleagues include rotation and slip; and the 2026 works of Seo et al. and Liu and Hashimoto treat friction/load-transfer or friction/torque feasibility in substantial detail [1-3,5,6]. Experimental validation of mobile-robot dynamics is also established practice, even where the vehicle layout differs [4].')
add_para(doc,'Planetary gear efficiency is a separate modelling concern. Analytical efficiency formulations exist [7], while dedicated experiments and power-loss models show dependence on speed, load, lubrication, bearing losses and planet load sharing [8,9]. A constant 0.92 efficiency per stage is suitable for a preliminary estimate only, not a universally valid measured value.')
add_h(doc,'2.1 Candidate contributions',2)
add_table(doc,['Candidate','Novelty potential after current scan','Feasibility / evidence required','Decision'],[
('A. Signed transmission + wheel-force feasibility model for this exact stage pairing','Low-to-moderate and unproven; configuration-specific rather than general 4WIS novelty','Derive signs, torque envelope, friction limits and compare against a transparent no-gear baseline; verify actual stage coupling and output member constraints.','Selected provisionally as the core contribution.'),
('B. Sensitivity of yaw acceleration / turning feasibility to L, mass, I_z, efficiency, traction and scrub torque','Potentially useful engineering result, but sensitivity analysis alone is unlikely to establish novelty.','Use CAD-based L and I_z; use motor datasheets and measured μ / efficiency ranges rather than arbitrary ranges.','Analytical sensitivity relations included; quantitative sweep deferred until parameters are grounded.'),
('C. Experimental identification and validation on the physical rover','Strongest route to defensible engineering contribution.','Instrument wheel speed, steering angle, motor current, IMU and ground-truth trajectory; run loaded and unloaded manoeuvres; quantify repeatability and uncertainty.','Essential future work, not available in supplied material.')
],[1.55,1.75,2.55,1.25],7.4)

add_h(doc,'3. System description and parameter provenance',1)
add_para(doc,'The source design describes four independent wheel modules on a square layout. The nominal 120 kg capacity is payload, not a complete operating-mass statement. A 30 kg payload share per module is used in the preliminary force calculations; chassis, battery, motors, gearbox housings and other hardware add mass and change both normal loads and yaw inertia. For actual dynamic simulation, total physical mass must be m = 120 kg + hardware mass, unless a measured scale weight gives another value.')
add_para(doc,'Table 2 distinguishes values taken from the design PDF from values still missing or used only as illustrative placeholders in the runnable example. “PDF” means the parameter appears in the supplied calculation document; it does not independently certify the value as physically measured or validated.')
params_rows=[
('Number of modules / layout','4; square; one at each corner','specified in PDF','Coordinates need the module centre spacing L from CAD.'),
('Payload','120 kg total; 30 kg nominal/module','specified in PDF','Not equal to total operating mass.'),
('Wheel geometry','190 mm diameter; r_w=0.095 m','specified in PDF','Rolling radius under load may differ.'),
('Speed / acceleration / grade','1.2 m/s; 0.8 m/s²; 5°','specified operating targets','Clarify whether maximum speed and acceleration must occur simultaneously.'),
('Resistance / traction','μ_r=0.02; μ=0.7','assumed in PDF','Require measurement on intended concrete/tire conditions.'),
('Steering patch approximation','μ_scrub=0.7; r_c=15 mm','specified in PDF','Patch geometry and steering-axis scrub radius need verification.'),
('Drive stage 1','Z_s=23, Z_p=23, Z_r=69; 4 planets; sun input / ring fixed / carrier output','specified in PDF','η_1=0.92 assumption.'),
('Drive stage 2','Z_s=23, Z_p=23, Z_r=69; 4 planets; sun input / carrier fixed / ring output','specified in PDF','Overall stage coupling is assumed carrier 1 → sun 2.'),
('Steering stage','Z_s=18, Z_p=36, Z_r=90; 3 planets; sun input / ring fixed / carrier output','specified in PDF','η_s=0.92 assumption.'),
('Drive motor','1.04 N m design minimum; 1.3 N m recommended continuous; 250 W recommended','recommendation, no model number','Actual torque-speed curve, peak duration and controller current limits absent.'),
('Steering motor','0.75 N m calculated design requirement; 1.0 N m recommended; 180-300 rpm','recommendation, no model number','Actual servo/BLDC continuous torque and torque-speed curve absent.'),
('Total physical mass m','120 kg payload + hardware mass','not provided','Weigh the assembled rover and loaded rover.'),
('Module spacing L','centre-to-centre square spacing','not provided','Measure from the CAD wheel-contact/module centres.'),
('Yaw inertia I_z','about CG, with payload installed','not provided','Obtain from mass-property CAD and verify if practical.'),
('Wheel/steering inertias and tire coefficients','J_w, J_δ, C_x, C_y','not provided','Measure, estimate from CAD, then identify using tests.'),
('CG offset, height, load transfer','position, height, load distribution','not provided','Needed for load transfer and uneven payload cases.')]
add_table(doc,['Parameter','Value / definition','Status','Model implication'],params_rows,[1.4,2.1,1.05,2.45],7.5)

add_h(doc,'4. Audit of preliminary calculations',1)
add_para(doc,'The following audit preserves source values where they are internally consistent and flags incomplete or incorrect results. Strength calculations and dynamic equations use different mass/load concepts: the factor of safety belongs in design-load checks, not in the physical dynamic mass.')
aud_rows=[]
for arow in audits:
    aud_rows.append((arow['item'],arow['source_value'],arow['recalculation'],arow['status'],arow['implication']))
add_table(doc,['Check','Value in PDF','Recalculation / finding','Status','Implication'],aud_rows,[1.05,1.3,2.05,1.0,1.65],6.8)
add_para(doc,'Additional engineering caution: the preliminary Lewis and Hertz calculations give very large nominal factors of safety, but their use as design ratings is not justified by the available record. A standards-based gear rating requires traceable load factors, gear quality, material heat-treatment data, life/duty assumptions, load sharing, dynamic factors and a clear load path. The geometric neighbour-clearance inequality in the PDF is not accompanied by a derivation; actual CAD clearance should be checked using addendum geometry, tolerances, deflection and assembly constraints.')

add_h(doc,'5. Mathematical formulation',1)
add_h(doc,'5.1 Coordinates and body kinematics',2)
add_para(doc,'The body frame is attached to the centre of gravity (CG), with +x forward, +y left and +z upward. Let (X,Y) be the CG position in the world frame, ψ the heading, (u,v) the longitudinal/lateral CG velocities expressed in body axes, and r = dψ/dt the yaw rate. Let module i be located at (x_i,y_i), measured from the CG, and let δ_i be its steering angle relative to the chassis.')
add_eq(doc,'v_ix = u − r y_i,      v_iy = v + r x_i',1)
add_eq(doc,'δ_i,ideal = atan2(v_iy, v_ix),      v_i = √(v_ix² + v_iy²)',2)
add_eq(doc,'ω_wi,ideal = v_i / r_w',3)
add_para(doc,'Equations (1)-(3) are inverse kinematics under ideal rolling in the wheel plane. They do not predict whether tire forces, actuator torque or steering-rate limits can realize the command. The implementation also considers the equivalent representation (δ_i+π, -ω_wi) and chooses the smaller steering-angle change to avoid unnecessary module rotation. When the requested local wheel velocity is zero, its steering angle is undefined; the controller retains the current angle instead of selecting an arbitrary direction.')
add_eq(doc,'[Ẋ, Ẏ]ᵀ = [[cosψ, −sinψ],[sinψ, cosψ]] [u, v]ᵀ,      ψ̇ = r',4)
add_para(doc,'For an in-place rotation about the CG, u=v=0 and r≠0. At any corner of a square with centre spacing L, √(x_i²+y_i²)=L/√2, so the ideal peripheral speed is |v_i|=|r|L/√2 and the wheel-speed magnitude is |ω_wi|=|r|L/(√2 r_w). This test is especially useful because it checks corner geometry and sign handling independently of a numerical solver.')

add_h(doc,'5.2 Signed planetary gear relationships',2)
add_para(doc,'For a simple planetary stage, the Willis relation is used with angular velocities measured about a common signed shaft axis:')
add_eq(doc,'(ω_s − ω_c)/(ω_r − ω_c) = − Z_r/Z_s',5)
add_para(doc,'Drive stage 1 has the ring fixed (ω_r=0), sun input and carrier output. Substitution gives ω_s−ω_c=(Z_r/Z_s)ω_c and therefore:')
add_eq(doc,'ω_c1/ω_m = Z_s/(Z_s+Z_r) = 23/92 = +1/4',6)
add_para(doc,'Drive stage 2 has the carrier fixed (ω_c=0), sun input and ring output. Therefore:')
add_eq(doc,'ω_w/ω_c1 = − Z_s/Z_r = −23/69 = −1/3',7)
add_para(doc,'Assuming the first carrier is coupled to the second sun, the signed overall ratio is:')
add_eq(doc,'ω_w/ω_m = ( +1/4 )( −1/3 ) = −1/12',8)
add_para(doc,'Thus the reduction magnitude is 12:1, but the output rotates opposite to the drive motor when both shaft coordinates use the same positive direction. A controller that stores only the positive magnitude can command the wrong direction. The sign must be present in inverse motor-speed conversion and torque mapping.')
add_para(doc,'The steering stage has its ring fixed, sun input, and carrier output. Applying (5) gives:')
add_eq(doc,'ω_c/ω_s = Z_s/(Z_s+Z_r) = 18/108 = +1/6',9)
add_para(doc,'For forward power flow and a stage efficiency η defined as output power divided by input power, the ideal torque magnitudes multiply by the reduction ratio while the delivered signed torque relation follows the signed speed ratio. With the stated axis convention:')
add_eq(doc,'τ_w = −12 η_d τ_m,     η_d = η_1 η_2 = 0.92² = 0.8464',10)
add_eq(doc,'τ_steer,out = +6 η_s τ_steer,m,     ω_steer,out = +ω_steer,m/6',11)
add_para(doc,'Equations (10)-(11) are lumped power-flow relations, not a detailed gear-mesh efficiency calculation. The simple product η_d=η_1η_2 assumes each stage has the same constant efficiency in the considered direction and operating region. Real gear-mesh and bearing losses vary with speed, load, lubrication and load sharing [7-9]. Reverse power flow, braking/regeneration, and transient gear inertia require a more detailed efficiency and drivetrain model.')
add_figure(doc,FIG/'fig3_signed_gear_ratios.png','Figure 1. Signed planetary speed relationships. The second drive stage reverses direction; the steering stage is separate from the drive train.',6.2)

add_h(doc,'5.3 Motor-speed and wheel-force feasibility',2)
add_para(doc,'At wheel radius r_w=0.095 m and a requested rover speed of 1.2 m/s, the ideal wheel angular speed is 12.632 rad/s, or approximately 120.62 rpm. The drive-motor speed magnitude is 12 times the wheel speed, 151.58 rad/s or about 1447.47 rpm; its sign is opposite under the chosen common-axis convention. With 0.8464 drivetrain efficiency, the per-module motor torque associated with a 5.274 N m wheel torque is 0.519 N m. Power provides a consistency check: the motor input is about 78.7 W/module for the payload-only operating point.')
add_para(doc,'For a motor torque-speed envelope, a simple continuous limit can be written as:')
add_eq(doc,'|τ_m| ≤ min(τ_m,cont, P_m,cont / max(|ω_m|, ε_ω))',12)
add_para(doc,'The wheel-shaft torque bound is |τ_w|≤12η_d|τ_m|. With wheel inertia and viscous loss, the gross longitudinal traction force compatible with commanded wheel torque is approximated from the wheel rotational balance:')
add_eq(doc,'J_w ω̇_w = τ_w − r_w F_t − b_w ω_w',13)
add_eq(doc,'F_t = (τ_w − J_w ω̇_w − b_w ω_w)/r_w',14)
add_para(doc,'The exact torque envelope must use the selected motor, drive electronics, supply voltage, peak-duration limit and thermal duty cycle. The PDF gives recommended motor classes and torque ratings but not a selected motor part number or full torque-speed curve, so the code uses a torque/power cap only for demonstration.')

add_h(doc,'5.4 Wheel-ground interaction and friction constraint',2)
add_para(doc,'Wheel-frame ground velocity components are:')
add_eq(doc,'V_xi = v_ix cosδ_i + v_iy sinδ_i',15)
add_eq(doc,'V_yi = −v_ix sinδ_i + v_iy cosδ_i',16)
add_para(doc,'Because the design PDF does not provide identified tire stiffness or a calibrated slip model, the runnable model uses a low-speed regularized creepage law rather than claiming a validated Pacejka or brush model. It is intentionally a placeholder constitutive law:')
add_eq(doc,'s_i = r_w ω_wi − V_xi,     F_xi,raw = C_x s_i,     F_yi,raw = −C_y V_yi',17)
add_eq(doc,'F_rr,i = μ_r N_i tanh(V_xi/v_ε)',18)
add_para(doc,'Define the raw net longitudinal demand as F_xi,raw−F_rr,i. A scalar saturation factor enforces a friction circle:')
add_eq(doc,'λ_i = min(1, μ N_i / √[(F_xi,raw−F_rr,i)² + F_yi,raw²])',19)
add_eq(doc,'F_ti = λ_i(F_xi,raw−F_rr,i) + F_rr,i,     F_li = λ_i F_yi,raw',20)
add_eq(doc,'√[(F_ti−F_rr,i)² + F_li²] ≤ μ N_i',21)
add_para(doc,'The friction circle captures the key fact that longitudinal propulsion/braking and lateral force share a finite contact-force capacity. It does not represent tire relaxation, a full slip-angle law, temperature, pressure, anisotropic terrain, or a calibrated combined-slip curve. The equal-load approximation used by the demo is N_i=mg cosα/4. It neglects load transfer, wheel lift, CG offset, and variations caused by slope/acceleration. A full vehicle model needs CG height and load distribution, not merely payload-per-module arithmetic.')
add_para(doc,'The wheel force is transformed into body axes as:')
add_eq(doc,'F_ix = (F_ti−F_rr,i) cosδ_i − F_li sinδ_i',22)
add_eq(doc,'F_iy = (F_ti−F_rr,i) sinδ_i + F_li cosδ_i',23)
add_para(doc,'The PDF estimates steering scrub torque as (2/3)μ_scrub N_i r_c. That expression assumes a circular contact patch with uniform pressure, but the same PDF estimates patch area using a 30 mm × 15 mm rectangle. This inconsistency makes scrub torque a parameter to identify, not a proven constant. In the simulation, an approximate ground-reaction torsional moment is treated separately from the steering motor joint torque. The steering motor torque is internal to the rover; it must not be inserted directly as an external chassis yaw moment. If patch torsion is explicitly modelled, its external ground reaction may enter the total yaw balance as a separate term, without counting it again through the point-force resultants.')

add_h(doc,'5.5 Coupled planar Newton-Euler equations',2)
add_para(doc,'Let F_x=Σ_i F_ix + F_x,ext and F_y=Σ_i F_iy + F_y,ext, where external terms include only effects not already represented in the wheel contact-force components (for example, grade force). The planar rigid-body equations are:')
add_eq(doc,'m(u̇ − r v) = F_x',24)
add_eq(doc,'m(v̇ + r u) = F_y',25)
add_eq(doc,'I_z ṙ = Σ_i (x_i F_iy − y_i F_ix) + M_z,ext',26)
add_para(doc,'If the patch-torsional scrub term is activated, M_z,ext includes the separately defined external ground-reaction couple; the motor-side steering torque is not itself treated as an external yaw torque. The yaw lever arms (x_i,y_i) must be relative to the actual CG. For an offset CG, module coordinates shift and the normal-load distribution must be recalculated. A constant-radius path has R=√(u²+v²)/|r| when the speed and yaw rate are nonzero and the motion is sufficiently steady; for negligible lateral velocity, R≈|u|/|r|.')
add_para(doc,'The state vector in the code is [X,Y,ψ,u,v,r,ω_w1…ω_w4,δ_1…δ_4,δ̇_1…δ̇_4]. The drive wheel dynamics are differential equations; steering module dynamics are represented by a torque-limited steering motor, steering inertia, damping and approximate scrub resistance. With regularized force laws and explicit saturation, the implemented model is an ODE. A model enforcing perfect no-slip constraints as algebraic equations, or adding contact complementarity and rigid gearing constraints, would instead require a constrained ODE/DAE formulation or a multibody solver.')
add_figure(doc,FIG/'fig1_rover_geometry.png','Figure 2. Square module geometry and ideal local velocities for positive yaw. The side spacing is a placeholder in the demonstration and must be replaced by CAD measurement.',5.1)
add_figure(doc,FIG/'fig5_rover_free_body.png','Figure 3. Conceptual planar free-body diagram for a positive-yaw force pattern. Force arrows are schematic, not measured results; use actual wheel coordinates relative to the centre of gravity.',6.2)
add_figure(doc,FIG/'fig2_model_architecture.png','Figure 4. Reduced-order coupling from commands through gear ratios and tire forces to planar dynamics.',6.2)

add_h(doc,'5.6 Closed-form turning feasibility',2)
add_para(doc,'The model yields an immediate first-order relation between actuator torque and yaw acceleration. Define the approximate maximum force per wheel as:')
add_eq(doc,'F_i,max ≈ min(12 η_d τ_m,max / r_w, μ N_i)',27)
add_para(doc,'This force bound omits wheel angular acceleration, motor power derating, steering resistance and combined-slip sharing; a conservative implementation should subtract the appropriate transient/loss terms and use the actual motor curve. For a symmetric square with steering directions tangent to circles about the CG, the moment arm magnitude of each module is L/√2. If each module provides tangential force F_tan of the same yaw-producing sign, then:')
add_eq(doc,'M_z ≈ 4(L/√2) F_tan = 2√2 L F_tan',28)
add_eq(doc,'|ṙ|_max ≈ (2√2 L/I_z) min_i(F_i,max)',29)
add_para(doc,'Equation (29) is an upper-bound style screening relation, not a full allocation solution: actual torque limits may differ by wheel, normal loads may not be equal, lateral tire demand consumes friction, and steering cannot instantaneously attain ideal tangential angles. It nevertheless exposes the key dependencies. Larger L increases moment arm and required wheel speed for a given yaw rate. Greater I_z reduces yaw acceleration. Lower gearbox efficiency or motor torque reduces achievable force. Lower friction reduces the available tire-force set. A commanded yaw trajectory is feasible only when the wheel-by-wheel force and actuator constraints are simultaneously satisfiable.')

add_h(doc,'6. Numerical verification and illustrative results',1)
add_para(doc,'The code executes eight analytical assertions: the two signed drive-stage ratios, combined drive ratio, steering ratio, straight-line steering angles, equal straight-line wheel speeds, in-place corner speed magnitude, and power consistency with the assumed efficiency. All eight checks pass. In addition, it simulates seven cases: straight translation/acceleration, crab motion, a constant-command curve, in-place rotation, steering at zero requested body twist, low-friction turning, and low-motor-torque turning. The two stress cases deliberately alter placeholder parameters to exercise the saturation logic; they are not claimed operating points for the real design. These are analytical/software verification checks, not physical validation.')
checks=json.loads((RESULT/'analytical_checks.json').read_text())
add_table(doc,['Verification check','Outcome'],[(k,'PASS' if v else 'FAIL') for k,v in checks.items()],[4.9,1.0],8)
num_checks=json.loads((RESULT/'numerical_checks.json').read_text())
add_table(doc,['Numerical check','Outcome'],[(k,'PASS' if v else 'FAIL') for k,v in num_checks.items()],[4.9,1.0],7.7)
doc.add_page_break()
op=json.loads((RESULT/'operating_point.json').read_text())
op_rows=[('Normal load per module at 5°',f"{op['normal_load_per_module_N']:.2f} N"),
('Rolling resistance per module',f"{op['rolling_resistance_per_module_N']:.2f} N"),
('Grade force per module',f"{op['grade_force_per_module_N']:.2f} N"),
('Acceleration force per module',f"{op['acceleration_force_per_module_N']:.2f} N"),
('Required longitudinal force/module',f"{op['required_drive_force_per_module_N']:.2f} N"),
('Friction-limited force/module',f"{op['traction_limit_per_module_N']:.2f} N"),
('Longitudinal traction utilization',f"{100*op['traction_utilization_fraction']:.1f}%"),
('Required wheel torque/module',f"{op['wheel_torque_per_module_Nm']:.3f} N m"),
('Required motor torque/module',f"{op['motor_torque_per_module_Nm']:.3f} N m"),
('Wheel speed at 1.2 m/s',f"{op['wheel_speed_at_1p2mps_rpm']:.2f} rpm"),
('Drive motor speed magnitude',f"{op['motor_speed_magnitude_rpm']:.2f} rpm"),
('Motor input power/module',f"{op['motor_power_per_module_W']:.2f} W"),
('Four-motor input power, payload-only',f"{op['four_module_motor_power_W']:.2f} W")]
add_table(doc,['Quantity','Recalculated value'],op_rows,[4.6,1.3],8.2)
add_para(doc,'These are per-module calculations using the nominal 30 kg payload share only, not a complete rover operating mass. The four-motor input estimate is about 315 W for the specified combined acceleration/grade operating point with no hardware mass; it must not be used as the final electrical-power requirement until chassis mass, transient drive losses, motor operating curves and duty cycle are known.')

sim_rows=[]
raw_sim_rows=[]
with (RESULT/'simulation_summary.csv').open(newline='') as f:
    for row in csv.DictReader(f):
        raw_sim_rows.append(row)
        label_map={'straight':'straight','crab':'crab','curve':'constant-command curve','in_place':'in-place','steer_stationary':'stationary steering','traction_limited_turn':'low-μ traction stress','motor_torque_limited_turn':'low-torque stress'}
        diag=(f"μmax={float(row['peak_friction_utilization']):.2f}; "
              f"tire-limit={100*float(row['fraction_saved_samples_any_wheel_at_friction_limit']):.0f}%; "
              f"motor-limit={100*float(row['fraction_saved_samples_any_wheel_motor_torque_saturated']):.0f}%")
        sim_rows.append((label_map.get(row['case'],row['case']),
                         f"({float(row['requested_u_m_s']):.2f}, {float(row['requested_v_m_s']):.2f}, {float(row['requested_yaw_rad_s']):.2f})",
                         f"({float(row['final_u_m_s']):.3f}, {float(row['final_v_m_s']):.3f}, {float(row['final_yaw_rate_rad_s']):.3f})",
                         f"({float(row['final_X_m']):.3f}, {float(row['final_Y_m']):.3f})", diag))
add_table(doc,['Case','Requested (u,v,r)','Final (u,v,r)','Final (X,Y)','Peak use / saturation'],sim_rows,[1.12,1.30,1.35,0.9,1.75],7.2)
summary_by_case={r['case']:r for r in raw_sim_rows}
tr=summary_by_case['traction_limited_turn']; mt=summary_by_case['motor_torque_limited_turn']
add_para(doc,f"The deliberately low-friction stress case (μ={float(tr['mu_traction']):.2f}) reaches the friction boundary (peak utilization {float(tr['peak_friction_utilization']):.2f}; at least one wheel is at the boundary at {100*float(tr['fraction_saved_samples_any_wheel_at_friction_limit']):.1f}% of saved samples). The low-torque case clips at least one drive motor at {100*float(mt['fraction_saved_samples_any_wheel_motor_torque_saturated']):.1f}% of saved samples. These checks show that the saturation code is exercised under constructed conditions; the selected stress-test parameters and trajectories are not validated predictions of the proposed rover.")
add_figure(doc,FIG/'fig4_demo_simulation.png','Figure 5. Controller-in-the-loop baseline motions under illustrative placeholder parameters. The two stress tests are summarized in the table but omitted from the plot to preserve readability. Curves are not validated performance predictions for the actual rover.',6.3)
add_para(doc,'In the baseline examples, the closed-loop response does not exactly reach the requested twist over the 2.5 s window. That is expected given the deliberately simple proportional wheel-speed controller, finite actuator torque, steering transient and arbitrary placeholder parameters. The numerical examples are not used to claim a particular turning radius, maximum yaw rate, or validated manoeuvre envelope. The useful present results are the signed gear derivations, force/torque bookkeeping and the explicit demonstration that model outputs depend on currently unmeasured parameters.')

add_h(doc,'7. Sensitivity relations and engineering implications',1)
add_para(doc,'A quantitative sensitivity sweep is not reported because physically justified ranges for the missing parameters are unavailable. Several normalized dependencies can nevertheless be derived directly from the equations:')
add_bullets(doc,[
'Longitudinal force demand under steady grade and acceleration is F_req = m[a_x + g sinα + μ_r g cosα], so required wheel torque and motor input power scale linearly with total mass for a fixed manoeuvre and fixed efficiency.',
'Motor torque scales inversely with total transmission efficiency: τ_m = F_req r_w/(12η_d). Treating both planetary stages as 0.92 efficient gives η_d=0.8464, but this should be replaced by measured loss data for a high-accuracy power model.',
'For symmetric loads, the ratio of the combined 5° grade + 0.8 m/s² acceleration + rolling demand to the friction limit is approximately [a_x + g sinα + μ_r g cosα]/[μ g cosα] ≈ 0.2705, independent of mass only if normal loads and required forces scale evenly and lateral forces are absent.',
'For a square module spacing L, ideal in-place wheel speed scales linearly with L at fixed yaw rate: |ω_w|=|r|L/(√2 r_w). Larger spacing increases yaw moment arm but also increases wheel speed required for the same yaw rate.',
'For fixed applied yaw moment, yaw acceleration is inversely proportional to I_z: ṙ=M_z/I_z. Therefore CAD-derived loaded yaw inertia is essential for numerical turning predictions.',
'Under a symmetric friction/torque-limited approximation, yaw-acceleration capacity scales with L/I_z and with the minimum of motor-derived force and μN. During combined translation and rotation, friction-circle allocation can reduce the available yaw moment below this upper bound.'
])
add_para(doc,'A defensible numerical sensitivity study should vary L over CAD manufacturing/packaging alternatives, mass and CG using weighed configurations, I_z using measured/CAD uncertainty, η using measured transmission loss, μ using repeatable surface tests, and steering scrub using identification trials. Choosing broad arbitrary parameter ranges simply to make appealing plots would create an impression of precision without evidence.')

add_h(doc,'8. Validation plan',1)
add_para(doc,'A mathematical model is not validated because it is dimensionally consistent or because an ODE solver converges. The following test programme is needed before the paper can report predictive turning performance.')
add_h(doc,'8.1 Required instrumentation and identification',2)
add_table(doc,['Quantity','Method / instrument','Suggested sampling / note'],[
('Wheel angular speed and drive motor speed','Encoders or high-resolution Hall/encoder telemetry; verify the -1/12 signed speed mapping on a stand','Synchronized ≥200 Hz logging; 1 kHz preferred if controller telemetry allows.'),
('Steering angle and rate','Absolute encoder per module; calibrate zero and angle sign; include gear backlash checks','≥200 Hz synchronized with wheel speeds.'),
('Drive/steering current, voltage and controller state','Motor-controller logs plus calibrated voltage/current measurement','≥500 Hz for transients if available; log current limits and thermal state.'),
('Body velocity, yaw rate and heading','IMU plus independent ground-truth position, e.g. motion capture indoors or suitable external localization','IMU 200 Hz or above; ground-truth position at a known synchronized rate.'),
('Total mass, CG and yaw inertia','Weigh empty/loaded rover; CAD mass properties; verify CG/inertia by an appropriate physical method if feasible','Repeat for unloaded and representative payload configurations.'),
('Tire friction and rolling resistance','Repeatable pull/traction tests on target concrete with target tires and normal loads','Report conditions, tire wear, surface cleaning, load and uncertainty.'),
('Drive gearbox efficiency','Input/output speed and torque or calibrated electrical/mechanical power measurements across load and speed','Use multiple points; do not infer one universal efficiency from a single point.'),
('Steering scrub torque','Steer a loaded module slowly under controlled conditions; record torque/current versus angle and direction','Include reversal, breakaway/stiction and repeatability; compare contact patch geometry assumptions.')
],[1.3,3.0,1.8],7.6)
add_h(doc,'8.2 Maneuvers and metrics',2)
add_numbered(doc,[
'Static steering sweep at several normal loads, in both directions, to identify steering resistance, motor torque and backlash.',
'Straight-line acceleration/deceleration on level concrete, then up/down the specified 5° grade, under unloaded and representative loaded conditions.',
'Crab motion at fixed low speed, including starts/stops and steering transitions.',
'Constant-radius turns at multiple speeds and radii, with measured yaw rate and lateral trajectory.',
'In-place rotation with symmetric steering targets, measuring translation drift, yaw acceleration and current saturation.',
'Combined translation and yaw manoeuvres near traction limit, conducted only under a controlled safety protocol and with a test plan approved for the rover.'
])
add_para(doc,'Use at least five repeats per nominal condition as a starting experimental design, increasing the count if repeatability is poor. Synchronize timestamps and quantify sensor calibration uncertainty. Compare predicted and measured u, v, yaw rate, heading, position, motor current and steering angle using bias, RMSE, maximum absolute error and confidence intervals across repeats. Define acceptable error thresholds before interpreting test outcomes. Parameter identification and validation data should be separated; fitting a tire coefficient and scoring the model on the same run is not independent validation.')
add_para(doc,'Analytical verification should include power flow through both drive stages, fixed-member constraints, mirrored left/right force cases, zero unintended yaw during symmetric straight motion, ideal in-place corner speeds, and limiting checks as μ→0 or torque limits are reduced. Numerical verification should include solver tolerance/time-step convergence, friction-circle saturation checks, and reproducibility of the reported CSV outputs. If no physical rover tests are available, conclusions must explicitly remain limited to symbolic analysis, analytical verification and illustrative numerical simulation.')

add_h(doc,'9. Limitations',1)
add_bullets(doc,[
'Total operating mass, module spacing, CG location and loaded yaw inertia are not supplied. In the code, m=120 kg is only a payload-only lower-bound illustration, L=0.80 m is an unverified placeholder, and I_z=12.8 kg m² assumes a uniformly distributed square mass for demonstration.',
'Tire coefficients C_x and C_y, wheel inertia, steering-module inertia, damping values and controller gains in the runnable example are illustrative placeholders. The low-speed regularized creepage law is not a validated tire model.',
'The code assumes equal static wheel normal loads and omits pitch/roll, load transfer, wheel unloading, compliance, backlash, wheel-module mass motion, thermal effects and regenerative/negative power flow.',
'Each planetary stage is assigned a constant 0.92 efficiency. The gear tooth bending/contact calculations in the PDF are screening estimates rather than a traceable rating-standard verification.',
'Steering scrub is based on an approximate contact-patch formula whose geometry does not match the rectangular patch dimensions also given in the PDF. The actual scrub radius and patch torsion must be identified.',
'There are no experimental measurements in the supplied material. The simulations are not claimed to validate the model or prove that the chosen motors are adequate under real operating conditions.',
'The literature review is targeted but not exhaustive, and exact novelty for the compound planetary arrangement has not been established.'
])

add_h(doc,'10. Conclusions',1)
add_para(doc,'A signed and friction-constrained modelling framework has been formulated for the specified four-wheel swerve rover and its two-stage drive / one-stage steering planetary transmissions. The drive train has an overall signed wheel-to-motor speed ratio of -1/12, while the steering carrier rotates at +1/6 of its motor/sun speed. Recalculation of the payload-only force estimate gives about 55.5 N per module for the stated simultaneous acceleration, grade and rolling-resistance condition, translating to approximately 5.27 N m wheel torque and 0.519 N m drive-motor torque per module at the specified speed under the assumed stage efficiencies. The source sheet’s bearing L10 life result is arithmetically high by approximately a factor of six: the standard basic-rating-life expression gives about 7.87×10^4 h under the stated equivalent load and speed, before checking the correctness of those load assumptions.')
add_para(doc,'The most important conclusion is methodological: signed kinematics, actuator torque limits and the friction-limited force set must be coupled before a requested yaw response can be called feasible. The code verifies several analytical relationships and runs a low-speed closed-loop demonstration, but its missing physical parameters and uncalibrated force law preclude a design-performance claim. A broad novelty claim for 4WIS/4WID dynamics is not supported by the targeted literature scan. The strongest route toward a publishable contribution is to replace placeholders with CAD/measured parameters, identify steering scrub and drivetrain losses, conduct loaded turning experiments, compare the proposed model against baseline kinematics and measured trajectories, and revise the novelty statement after a wider literature review.')

add_h(doc,'References',1)
refs=[
'[1] M.-H. Lee and T.-H. S. Li, “Kinematics, dynamics and control design of 4WIS4WID mobile robots,” The Journal of Engineering, vol. 2015, no. 1, pp. 6-16, 2015. https://doi.org/10.1049/joe.2014.0241',
'[2] H. Zheng and S. Yang, “A Trajectory Tracking Control Strategy of 4WIS/4WID Electric Vehicle with Adaptation of Driving Conditions,” Applied Sciences, vol. 9, no. 1, article 168, 2019. https://doi.org/10.3390/app9010168',
'[3] A. Jaskot, B. Posiadała, and S. Śpiewak, “Dynamics modelling of the four-wheeled mobile platform,” Mechanics Research Communications, vol. 83, pp. 58-64, 2017. https://doi.org/10.1016/j.mechrescom.2017.05.007',
'[4] D. Hong, S. A. Velinsky, and X. Feng, “Verification of a Wheeled Mobile Robot Dynamic Model and Control Ramifications,” Journal of Dynamic Systems, Measurement, and Control, vol. 121, no. 1, pp. 58-63, 1999. https://doi.org/10.1115/1.2802442',
'[5] D. Seo, S. Moon, and J. Kang, “Unified motion control of 4WIS-4WID WMR with unlimited steering and load transfer consideration,” Robotics and Autonomous Systems, vol. 198, article 105341, 2026. https://doi.org/10.1016/j.robot.2026.105341',
'[6] R. Liu and K. Hashimoto, “Friction-Aware Force-Realizable Safety Control for Four-Wheel Independently Steered and Driven Mobile Robots,” International Journal of Robust and Nonlinear Control, early view, first published 3 October 2026. https://doi.org/10.1002/rnc.70772',
'[7] J. M. del Castillo, “The analytical expression of the efficiency of planetary gear trains,” Mechanism and Machine Theory, vol. 37, no. 2, pp. 197-214, 2002. https://doi.org/10.1016/S0094-114X(01)00077-5',
'[8] D. C. Talbot, A. Kahraman, and A. Singh, “An Experimental Investigation of the Efficiency of Planetary Gear Sets,” Journal of Mechanical Design, vol. 134, no. 2, article 021003, 2012. https://doi.org/10.1115/1.4005599',
'[9] C. Nutakor, A. Kłodowski, J. Sopanen, A. Mikkola, and J. I. Pedrero, “Planetary gear sets power loss modeling: Application to wind turbines,” Tribology International, vol. 105, pp. 42-54, 2017. https://doi.org/10.1016/j.triboint.2016.09.029',
'[10] J.-B. Song and K.-S. Byun, “Design and Control of a Four-Wheeled Omnidirectional Mobile Robot with Steerable Omnidirectional Wheels,” Journal of Robotic Systems, vol. 21, no. 4, pp. 193-208, 2004. https://doi.org/10.1002/rob.20009'
]
for ref in refs:
    p=doc.add_paragraph()
    p.paragraph_format.left_indent=Inches(0.18); p.paragraph_format.first_line_indent=Inches(-0.18)
    p.paragraph_format.space_after=Pt(3)
    run=p.add_run(ref); run.font.size=Pt(8.4)

add_h(doc,'Appendix A. Reproducibility and parameter substitution',1)
add_para(doc,'The executable reference implementation is swerve_rover_model.py. It writes analytical_checks.json, numerical_checks.json, operating_point.json, parameter_config.json, seven simulation CSV files, a simulation summary CSV, case-specific configuration JSON, and five figures. To run it in an environment with Python 3.10 or newer plus NumPy, SciPy and Matplotlib installed:')
p=doc.add_paragraph(); p.paragraph_format.left_indent=Inches(0.25)
r=p.add_run('python swerve_rover_model.py --outdir results --duration 2.5'); r.font.name='Consolas'; r.font.size=Pt(9)
add_para(doc,'Before interpreting simulation values, replace Params.total_mass, Params.module_spacing, Params.yaw_inertia, wheel/steering inertias, tire coefficients, motor torque/power limits, and steering resistance with source-traceable values. For total mass use a scale measurement, not the factor-of-safety-adjusted design load. For I_z, use CAD mass properties with the payload placed realistically. The code’s default 120 kg mass is explicitly the payload-only illustration; it is not asserted to be the assembled rover mass.')
add_para(doc,'The internal parameter configuration labels values from the supplied PDF versus illustrative placeholders in the source comments and the package README. Store the exact measured parameter set and versioned code revision with every future experimental result so each plot can be reproduced.')

add_h(doc,'Appendix B. Pre-submission referee-style assessment',1)
add_para(doc,'Major concerns likely to be raised by a skeptical reviewer:')
add_manual_numbered(doc,[
'Novelty is not yet sufficiently narrow or proven. 4WIS/4WID kinematics, dynamics, slip, tire-force allocation and friction constraints are all established. The manuscript should show exactly what the signed stage-2 ring-output planetary configuration adds beyond the literature, ideally as a torque/yaw-feasibility result verified on hardware.',
'The model is not identifiable from the current data. Total mass, geometry, I_z, selected motor data and tire characteristics are absent. An illustrative example does not support performance claims.',
'There is no experimental validation. To report quantitative prediction accuracy, measure turning trajectories and wheel/steering states; simulation-to-simulation comparison is only verification against equations or a baseline.',
'The tire law is a low-speed regularized proxy, not a validated tire-ground model. A reviewer may ask for a physically justified slip-angle/combined-slip model or a clear scope limited to a simplified design model.',
'The source gear and bearing strength checks are not sufficiently traceable to accepted rating methods. The bearing-life arithmetic correction and a standard-based gear rating should be completed before mechanical safety claims are made.'
])
add_para(doc,'Minor concerns and corrections: sign conventions should be shown next to every drive-speed conversion; the stage-2 reverse direction must not be hidden by absolute ratios; the 0.92² notation must be written unambiguously; the force value of 55.5 N must be labelled per module; the factor of safety must not inflate simulated mass; the steering contact patch assumptions should be reconciled; and figure captions should state which values are illustrative.')
add_para(doc,'Recommendation: major revision before submission. The present package is useful as a reproducible design-analysis starting point and a rigorous audit of the preliminary calculation sheet. It should not be described as guaranteed publication-ready. A stronger journal case would require the model fitted/identified from a real rover, independent manoeuvre validation, a documented comparison to at least one baseline, and a broader novelty review.')

# Metadata
doc.core_properties.title='Configuration-Specific Modelling and Feasibility Audit of a Four-Wheel Swerve-Drive Rover'
doc.core_properties.subject='Mathematical model, planetary gear audit, swerve-drive dynamics and validation plan'
doc.core_properties.author='OpenAI'
doc.core_properties.keywords='swerve drive, 4WIS4WID, planetary gear, rover dynamics, validation'
doc.save(OUT)
print(f'Wrote {OUT}')
